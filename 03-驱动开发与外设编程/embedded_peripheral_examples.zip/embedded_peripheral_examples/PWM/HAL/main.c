// PWM HAL 驱动示例代码（基于 STM32CubeMX）
