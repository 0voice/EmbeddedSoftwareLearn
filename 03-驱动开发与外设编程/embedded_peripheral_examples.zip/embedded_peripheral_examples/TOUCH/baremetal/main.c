// TOUCH 裸机驱动示例代码
